# 2024-12-01T18:49:31.934668300
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Vivado_Projects/rsa_algorithm/rsa_algorithm.srcs")

vitis.dispose()

